* copy libmylist.a to the directory that contains this file.
* run `make check`
